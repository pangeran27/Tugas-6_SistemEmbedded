#include <Arduino.h>
#include <Servo.h>

Servo myServo;
#define SERVO_PIN PB0
#define POT_PIN   PA1

int lastAngle = 0;

void setup() {
    Serial.begin(115200);
    delay(2000);
    Serial.println("Program 08: Servo - STM32\n");

    // Menambahkan range pulse width standar SG90 (500us - 2400us)
    // Ini membantu jika servo tidak merespon sinyal default
    myServo.attach(SERVO_PIN, 500, 2400);

    // Tes gerakan servo saat startup untuk memastikan hardware OK
    Serial.println("Testing Servo Movement...");
    myServo.write(0);  delay(1000);
    myServo.write(90); delay(1000);
    myServo.write(180); delay(1000);
    Serial.println("Test Complete. Starting Loop...");
    
    pinMode(POT_PIN, INPUT_ANALOG);
}

void loop() {
    int pot = analogRead(POT_PIN);
    // Mengubah rentang map ke 0-180 derajat sesuai standar servo SG90
    int angle = map(pot, 0, 4095, 0, 180);

    // Hanya update jika perubahan sudut lebih dari 1 derajat untuk mengurangi jitter
    if (abs(angle - lastAngle) > 1) {
        myServo.write(angle);
        Serial.printf("ADC: %d | Angle: %d deg\n", pot, angle);
        lastAngle = angle;
    }
    delay(20); // Delay lebih kecil untuk respon yang lebih cepat
}
